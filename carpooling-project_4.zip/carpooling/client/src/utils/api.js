import axios from "axios";

const api = axios.create({
  baseURL: "/api",
});

// attach the token on every request so we don't repeat this in every component
api.interceptors.request.use((config) => {
  const user = JSON.parse(localStorage.getItem("carpoolUser") || "{}");
  if (user.token) {
    config.headers.Authorization = `Bearer ${user.token}`;
  }
  return config;
});

export default api;
