import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import styles from "./Navbar.module.css";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <nav className={styles.nav}>
      <Link to="/" className={styles.logo}>
        RideShare
      </Link>

      <div className={styles.links}>
        <Link to="/rides">Find a Ride</Link>

        {user ? (
          <>
            {user.role === "driver" && <Link to="/post-ride">Post a Ride</Link>}
            <Link to="/dashboard">Dashboard</Link>
            <span className={styles.username}>Hi, {user.name.split(" ")[0]}</span>
            <button onClick={handleLogout} className={styles.logoutBtn}>
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register" className={styles.registerBtn}>
              Sign Up
            </Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
